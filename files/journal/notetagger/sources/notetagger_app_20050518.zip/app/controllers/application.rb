# The filters added to this controller will be run for all controllers in the application.
# Likewise will all the methods added be available for all controllers.
require 'user_system'

class ApplicationController < ActionController::Base
  include UserSystem
  helper :user
  model :user

  before_filter :login_required
  before_filter :setup_environment
  
  private 
  
  def setup_environment
    @user_account = User.find_by_login(request.subdomains.first)
    @current_user = session['user'] rescue nil
  end
  
end