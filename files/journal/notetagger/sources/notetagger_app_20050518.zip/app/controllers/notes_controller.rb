require_dependency 'redcloth'

class NotesController < ApplicationController
  layout 'application', :except => {'create_with_ajax', 'destroy_with_ajax'}

  after_filter :pass_highlight_id

  def protect?(action)
    false
  end

  def index
    list
    render_action 'list'
  end

  def list
    @notes = Note.find(:all, :conditions => ['author_id = ?', @user_account.id], :order => 'created_at DESC')
    @highlight_id = flash['highlight']    
  end

  def tag
    @tag = Tag.find_by_name(@params[:id])    
    @notes = @tag.notes
    render 'notes/list'
  end

  def show
    @note = Note.find(@params[:id])
  end

  def new
    @note = Note.new
  end

  def create
    @note = Note.new(@params[:note].merge({author_id => @current_user.id}))
    if @note.save
      flash['notice'] = 'Note was successfully created.'
      flash['highlight'] = "note#{@note.id}"
      redirect_to :action => 'list'
    else
      render_action 'new'
    end
  end

  def create_with_ajax
    @note = Note.new(@params[:note].merge({'author_id' => @current_user.id}))
    if @note.save
      @notes = Note.find(:all, :conditions => ['author_id = ?', @user_account.id], :order => 'created_at DESC')
      flash['highlight'] = "note#{@note.id}"
      render_partial 'list'
    end
  end

  def edit
    @note = Note.find(@params[:id])
  end

  def update
    @note = Note.find(@params[:id])
    if @note.update_attributes(@params[:note])
      flash['notice'] = 'Note was successfully updated.'
      flash['highlight'] = "note#{@note.id}"
      redirect_to :action => 'list'
    else
      render_action 'edit'
    end
  end

  def destroy
    Note.find(@params[:id]).destroy
    redirect_to :action => 'list'
  end

  def destroy_with_ajax
    Note.find(@params[:id]).destroy  
    # @notes = Note.find_all(nil, 'created_at DESC')
    # render_partial 'list'
    render_text ""
  end

  def pass_highlight_id
    @highlight_id = flash['highlight']
  end
end
