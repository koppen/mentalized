class Note < ActiveRecord::Base
  has_and_belongs_to_many :tags
  
  after_save :update_tags
  
  # Maintains the tag associations
  def update_tags    
    self.tags.clear
    for tag_name in self.tag_string.split      
      tag = Tag.new(:name => tag_name) unless (tag = Tag.find_by_name(tag_name))
      self.tags.push(tag)
    end
  end
end
