# The methods added to this helper will be available to all templates in the application.
module ApplicationHelper

  # Returns a link to the given tag
  def link_to_tag(tag, total_tags = nil)
    
    if total_tags.nil?  
      return link_to "#{tag.name} (#{tag.notes.size})", :action => 'tag', :id => tag.name
    else
      # We have a tag count, add a "level" CSS class to the tag link. level 
      # needs to be a number from 0 to 9.
      level = ((tag.notes.size * 10) / total_tags).to_i
      return link_to "#{tag.name}", {:action => 'tag', :id => tag.name}, :class => "level#{level}"
    end

  end
  
end
