require_dependency 'redcloth'

class NotesController < ApplicationController
  layout 'notes', :except => {'create_with_ajax', 'delete_with_ajax'}

  def index
    list
    render_action 'list'
  end

  def list
    @notes = Note.find_all(nil, 'created_at DESC')
  end

  def show
    @note = Note.find(@params[:id])
  end

  def new
    @note = Note.new
  end

  def create
    @note = Note.new(@params[:note])
    if @note.save
      flash['notice'] = 'Note was successfully created.'
      redirect_to :action => 'list'
    else
      render_action 'new'
    end
  end

  def create_with_ajax
    @note = Note.new(@params[:note])
    if @note.save
      @notes = Note.find_all(nil, 'created_at DESC')
      render_partial 'list'
    end
  end

  def edit
    @note = Note.find(@params[:id])
  end

  def update
    @note = Note.find(@params[:id])
    if @note.update_attributes(@params[:note])
      flash['notice'] = 'Note was successfully updated.'
      redirect_to :action => 'show', :id => @note
    else
      render_action 'edit'
    end
  end

  def destroy
    Note.find(@params[:id]).destroy
    redirect_to :action => 'list'
  end

  def destroy_with_ajax
    Note.find(@params[:id]).destroy  
    @notes = Note.find_all(nil, 'created_at DESC')
    render_partial 'list'
  end

  def tag
    @tag = Tag.find_by_name(@params[:id])    
    @notes = @tag.notes
    render 'notes/list'
  end
end
